package hk.edu.cuhk.ie.iems5722.a2_1155072356;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by huangdanlei on 16/2/23.
 */
public class Http extends AsyncTask<String, Void, String> {
    private static final String DEBUG_TAG = "Http";

    public interface AsyncResponse {
        public void processFinish(String output);
    }
    public AsyncResponse delegate=null;
    public Http(AsyncResponse delegate){
        this.delegate=delegate;
    }

    @Override
    protected void onPostExecute(String result) {
        delegate.processFinish(result);
    }

    @Override
    protected String doInBackground(String... urls) {
        int len=500;
        InputStream is=null;
        try {

            URL url = new URL(urls[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(100000);
            connection.setConnectTimeout(150000);
            connection.setRequestMethod("GET");
            connection.connect();
            int response = connection.getResponseCode();
            Log.d(DEBUG_TAG, "the response is: " + response);
            is= connection.getInputStream();
            String contentAsString = readIt(is, len);
            return contentAsString;
        } catch (IOException e) {
            return "Unable to retrieve web page. URL may be invalid.";
        }
    }
    BufferedReader reader = null;
    StringBuilder builder=null;
    String line=null;

    public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
        reader =new BufferedReader( new InputStreamReader(stream, "UTF-8"));
        builder=new StringBuilder();
        while ((line=reader.readLine())!=null){
            builder.append(line);
        }
        return builder.toString();

    }

}

