package hk.edu.cuhk.ie.iems5722.a2_1155072356;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by huangdanlei on 16/2/24.
 */


public class UserAdapter extends ArrayAdapter<User> {
    private int ID;
    class ViewHolder{
        LinearLayout leftlayout;
        LinearLayout rightlayout;
        TextView receive_user_id;
        TextView receive_name;
        TextView receive_message;
        TextView receive_time;
        TextView send_user_id;
        TextView send_name;
        TextView send_message;
        TextView send_time;
    }
    public UserAdapter(Context context,int textviewId,ArrayList<User> users){
        super(context,textviewId,users);
        ID=textviewId;
    }
    @Override
    public View getView(int position,View convertView,ViewGroup parent){
        User user=getItem(position);
        View view;
        ViewHolder viewHolder;

        if (convertView==null){
            view=LayoutInflater.from(getContext()).inflate(ID,null);
            viewHolder=new ViewHolder();
            viewHolder.leftlayout=(LinearLayout)view.findViewById(R.id.linearLayout_l);
            viewHolder.rightlayout=(LinearLayout)view.findViewById(R.id.linearLayout_r);
            viewHolder.receive_user_id=(TextView)view.findViewById(R.id.receive_user_id);
            viewHolder.receive_name=(TextView)view.findViewById(R.id.receive_name);
            viewHolder.receive_message=(TextView)view.findViewById(R.id.receive_message);
            viewHolder.receive_time=(TextView)view.findViewById(R.id.receive_time);
            viewHolder.send_user_id=(TextView)view.findViewById(R.id.send_user_id);
            viewHolder.send_name=(TextView)view.findViewById(R.id.send_name);
            viewHolder.send_message=(TextView)view.findViewById(R.id.send_message);
            viewHolder.send_time=(TextView)view.findViewById(R.id.send_time);

            view.setTag(viewHolder);
        }else {
            view=convertView;
            viewHolder=(ViewHolder)view.getTag();
        }
        if (user.getType()==user.receive_type){
            if (user.user_id.equals("1155072356")){
                viewHolder.leftlayout.setVisibility(View.GONE);
                viewHolder.rightlayout.setVisibility(View.VISIBLE);
                viewHolder.send_user_id.setText(user.getUser_id());
                viewHolder.send_name.setText(user.getName());
                viewHolder.send_message.setText(user.getMessage());
                viewHolder.send_time.setText(user.getTimestamp());
            }else {

                viewHolder.leftlayout.setVisibility(View.VISIBLE);
                viewHolder.rightlayout.setVisibility(View.GONE);
                viewHolder.receive_user_id.setText(user.getUser_id());
                viewHolder.receive_name.setText(user.getName());
                viewHolder.receive_message.setText(user.getMessage());
                viewHolder.receive_time.setText(user.getTimestamp());
            }
        } else if (user.getType()==user.send_type){
            viewHolder.leftlayout.setVisibility(View.GONE);
            viewHolder.rightlayout.setVisibility(View.VISIBLE);
            viewHolder.send_user_id.setText(user.getUser_id());
            viewHolder.send_name.setText(user.getName());
            viewHolder.send_message.setText(user.getMessage());
            viewHolder.send_time.setText(user.getTimestamp());
        }

        return view;
    }
}
