package hk.edu.cuhk.ie.iems5722.a2_1155072356;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * Created by huangdanlei on 16/2/24.
 */
public class Post extends AsyncTask<String, Void, String> {
    private static final String DEBUG_TAG = "Http";
    Map<String,String> params;


    public interface AsyncResponse {
        public void processFinish(String output);
    }

    public AsyncResponse delegate = null;

    public Post(AsyncResponse delegate) {
        this.delegate = delegate;
    }

    @Override
    protected void onPostExecute(String result) {
        delegate.processFinish(result);
    }

    @Override
    protected String doInBackground(String... urls) {
        try {

            URL url_object = new URL("http://54.249.95.206/iems5722/send_message");
            HttpURLConnection connection = (HttpURLConnection) url_object.openConnection();
            connection.setReadTimeout(15000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoOutput(true);

            OutputStream outputStream = connection.getOutputStream();

            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));



            writer.write(urls[0]);
            writer.flush();
            writer.close();
            outputStream.close();

            int responceCode=connection.getResponseCode();
            if (responceCode==HttpURLConnection.HTTP_OK){
                InputStream inputStream=null;
                inputStream=connection.getInputStream();
                String data="";
                String line;
                BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));
                while ((line=reader.readLine())!=null){
                    data+=line;
                }

                    if (inputStream!=null){
                        inputStream.close();
                    }

            }


        } catch (IOException e) {
            return "Unable to retrieve web page. URL may be invalid.";
        }
        return "";
    }
}
