package hk.edu.cuhk.ie.iems5722.a2_1155072356;

/**
 * Created by huangdanlei on 16/2/24.
 */
public class User {
    public String message;
    public String name;
    public String timestamp;
    public String user_id;
    private int type;
    public static final int receive_type=0;
    public static final int send_type=1;


    public User(String user_id,String message,String name,String timestamp, int type){
        this.user_id=user_id;
        this.message=message;
        this.name=name;
        this.timestamp=timestamp;
        this.type=type;
    }
    public String getUser_id(){
        return user_id;
    }
    public String getName(){
        return name;
    }
    public String getMessage(){
        return message;
    }
    public String getTimestamp(){
        return timestamp;
    }
    public int getType(){
        return type;
    }
}
