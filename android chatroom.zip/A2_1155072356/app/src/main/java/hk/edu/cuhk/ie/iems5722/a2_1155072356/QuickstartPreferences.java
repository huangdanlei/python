package hk.edu.cuhk.ie.iems5722.a2_1155072356;

/**
 * Created by huangdanlei on 16/4/6.
 */
public class QuickstartPreferences {
    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
