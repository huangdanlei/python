package hk.edu.cuhk.ie.iems5722.a2_1155072356;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {
    private ImageButton imageButton;
    private EditText editText;
    private ListView listView;
    private UserAdapter adapter;
    private SimpleDateFormat SDF;
    private JSONObject jsonObject;
    private Menu optionsMenu;
    ArrayList<User> arrayOfUsers = new ArrayList<User>();
    private int lastVisible;
    private Runnable runnable;
    private int current_page;
    private int total_pages;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        final String id = getIntent().getStringExtra("id");

        String stringurl2 = "http://54.249.95.206/iems5722/get_messages?chatroom_id=" + id + "&page=1";
        Http http2 = new Http(new Http.AsyncResponse() {
            @Override
            public void processFinish(String output) {

                String DATA = output;
                try {
                    jsonObject = (JSONObject) new JSONTokener(DATA).nextValue();
                    JSONObject data = jsonObject.getJSONObject("data");
                    current_page=data.getInt("current_page");
                    total_pages=data.getInt("total_pages");
                    JSONArray jsonArray = data.getJSONArray("messages");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        String id = jsonArray.getJSONObject(i).getString("user_id");
                        String name = jsonArray.getJSONObject(i).getString("name");
                        String message = jsonArray.getJSONObject(i).getString("message");
                        String timestamp = jsonArray.getJSONObject(i).getString("timestamp");
                        User newUser = new User(id,name, message, timestamp, User.receive_type);
                        arrayOfUsers.add(0,newUser);
                        adapter.notifyDataSetChanged();
                    }
                } catch (JSONException ex) {
                    Log.e("JSONExpection", ex.getMessage());
                }
            }
        });

        http2.execute(stringurl2);
        listView = (ListView) findViewById(R.id.listView);
        adapter = new UserAdapter(this, R.layout.item_user, arrayOfUsers);
        listView.setAdapter(adapter);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                listView.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
                if (listView.getFirstVisiblePosition() == 0 && scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {

                    LoadingData();

                }
            }


            private void LoadingData() {
                current_page++;
                if (current_page <= total_pages) {
                    final String id = getIntent().getStringExtra("id");
                    String stringurl2 = "http://54.249.95.206/iems5722/get_messages?chatroom_id=" + id + "&page=" + current_page;
                    Http http2 = new Http(new Http.AsyncResponse() {
                        @Override
                        public void processFinish(String output) {

                            String DATA = output;
                            try {
                                jsonObject = (JSONObject) new JSONTokener(DATA).nextValue();
                                JSONObject data = jsonObject.getJSONObject("data");
                                JSONArray jsonArray = data.getJSONArray("messages");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    String id = jsonArray.getJSONObject(i).getString("user_id");
                                    String name = jsonArray.getJSONObject(i).getString("name");
                                    String message = jsonArray.getJSONObject(i).getString("message");
                                    String timestamp = jsonArray.getJSONObject(i).getString("timestamp");
                                    User newUser = new User(id, name, message, timestamp, User.receive_type);
                                    arrayOfUsers.add(0, newUser);
                                    adapter.notifyDataSetChanged();
                                }
                            } catch (JSONException ex) {
                                Log.e("JSONExpection", ex.getMessage());
                            }
                        }
                    });

                    http2.execute(stringurl2);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                lastVisible = totalItemCount;
                Log.d("TAG", String.valueOf(lastVisible) + "lastVisible");
            }
        });








        editText=(EditText)findViewById(R.id.edit_text);
        imageButton=(ImageButton)findViewById(R.id.image_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String inputcontent1= editText.getText().toString();
                long date=System.currentTimeMillis();
                SDF=new SimpleDateFormat("HH:MM");
                final String Time=SDF.format(date);
                final String name="HUANG DANLEI";
                final String user_id="1155072356";
                final String inputcontent=inputcontent1.trim();
                if (inputcontent.equals("")){
                    editText.setError("Please input content :)");
                }
                else {

                    User newUser=new User(user_id,name,inputcontent,Time,User.send_type);
                    String stringurl3="chatroom_id="+id+"&user_id="+1155072356+"&name="+name+"&message="+inputcontent;
                    Post post=new Post(new Post.AsyncResponse() {
                        @Override
                        public void processFinish(String output) {

                        }

                    });
                    post.execute(stringurl3);

                    adapter.add(newUser);
                    editText.setText("");
                    adapter.notifyDataSetChanged();


                }

            }
        });


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void setRefreshActionButtonState(final boolean refreshing) {
        if (optionsMenu != null) {
            final MenuItem refreshItem = optionsMenu
                    .findItem(R.id.refresh);
            if (refreshItem != null) {
                if (refreshing) {
                    refreshItem.setActionView(R.layout.actionbar_indeterminate_progress);
                } else {
                    refreshItem.setActionView(null);
                }
            }
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.optionsMenu=menu;
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.refresh:
                setRefreshActionButtonState(true);
                refresh();
                setRefreshActionButtonState(false);
                return true;

        }

        return super.onOptionsItemSelected(item);
    }
protected void refresh(){
    arrayOfUsers.clear();
    final String id = getIntent().getStringExtra("id");
    String stringurl2 = "http://54.249.95.206/iems5722/get_messages?chatroom_id=" + id + "&page=1";
    Http http2 = new Http(new Http.AsyncResponse() {
        @Override
        public void processFinish(String output) {

            String DATA = output;
            try {
                jsonObject = (JSONObject) new JSONTokener(DATA).nextValue();
                JSONObject data = jsonObject.getJSONObject("data");
                current_page=data.getInt("current_page");
                total_pages=data.getInt("total_pages");
                JSONArray jsonArray = data.getJSONArray("messages");

                for (int i = 0; i < jsonArray.length(); i++) {
                    String id = jsonArray.getJSONObject(i).getString("user_id");
                    String name = jsonArray.getJSONObject(i).getString("name");
                    String message = jsonArray.getJSONObject(i).getString("message");
                    String timestamp = jsonArray.getJSONObject(i).getString("timestamp");
                    User newUser = new User(id,name, message, timestamp, User.receive_type);
                    arrayOfUsers.add(0,newUser);
                    adapter.notifyDataSetChanged();
                }
            } catch (JSONException ex) {
                Log.e("JSONExpection", ex.getMessage());
            }
        }
    });
    http2.execute(stringurl2);
}
}
